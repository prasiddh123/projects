#ifndef TIMER_H
#define TIMER_H

void configure_timer();

void clear_timer() ;

void start_timer() ;

double stop_timer() ;

#endif // TIMER_H
